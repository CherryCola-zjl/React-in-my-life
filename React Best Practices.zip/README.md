# yuejing-overseas
welcome to yuejing nft platform!!

## scripts:

```js
// dev env
npm run start
npm run build:dev
// prod env
npm run start:prod
npm run build:prod
```